document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("themeToggle");
  const savedTheme = localStorage.getItem("mundoFitnessTheme");
  if (savedTheme === "dark") document.body.classList.add("dark-mode");
  function updateThemeButton() {
    if (!toggle) return;
    toggle.innerHTML = document.body.classList.contains("dark-mode")
      ? '<i class="bi bi-sun-fill"></i> Modo claro'
      : '<i class="bi bi-moon-stars-fill"></i> Modo oscuro';
  }
  updateThemeButton();
  toggle?.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    localStorage.setItem("mundoFitnessTheme", document.body.classList.contains("dark-mode") ? "dark" : "light");
    updateThemeButton();
  });

  document.querySelectorAll("#year").forEach(el => el.textContent = new Date().getFullYear());

  const topButton = document.getElementById("topButton");
  if (topButton) {
    window.addEventListener("scroll", () => topButton.classList.toggle("show", window.scrollY > 350));
    topButton.addEventListener("click", () => window.scrollTo({top: 0, behavior: "smooth"}));
  }

  const contactForm = document.getElementById("contactForm");
  contactForm?.addEventListener("submit", event => {
    event.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();
    const subject = encodeURIComponent("Mensaje desde Mundo Fitness");
    const body = encodeURIComponent(`Nombre: ${name}\nCorreo: ${email}\n\nMensaje:\n${message}`);
    document.getElementById("contactAlert").classList.remove("d-none");
    // IMPORTANTE: reemplazar por el correo real antes de publicar.
    window.location.href = `mailto:TU_CORREO@EJEMPLO.COM?subject=${subject}&body=${body}`;
  });
});