# Mundo Fitness — Proyecto de portafolio

**Estudiante:** Yanko Abrahan Muñoz Guillén  
**Matrícula:** 24-0972

## Archivos
- `index.html`: página principal.
- `noticias.html`: artículos.
- `enlaces.html`: video de YouTube, mapa de Google Maps y recursos.
- `contacto.html`: formulario que prepara un correo mediante `mailto`.
- `css/styles.css`: estilos personalizados.
- `js/script.js`: modo oscuro, botón volver arriba, año automático y formulario.
- `img/favicon.svg`: icono personalizado.

## Antes de publicar
1. Abre `contacto.html` y `js/script.js`.
2. Reemplaza `TU_CORREO@EJEMPLO.COM` por tu correo real.
3. Si deseas, reemplaza los enlaces de Instagram/Facebook/YouTube por tus perfiles.
4. Prueba la página abriendo `index.html` en Chrome.

## Publicar en GitHub Pages
1. Entra a https://github.com e inicia sesión.
2. Crea un repositorio nuevo llamado `mundo-fitness`.
3. Sube todos los archivos y carpetas de este proyecto (no solo el ZIP).
4. En el repositorio, entra en **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**.
6. Selecciona la rama `main` y la carpeta `/ (root)`. Guarda.
7. Espera a que GitHub Pages genere la dirección pública. Normalmente será `https://TU-USUARIO.github.io/mundo-fitness/`.
8. Entrega en la plataforma la URL publicada y la URL del repositorio.

## Tecnologías
HTML5, CSS3, JavaScript, Bootstrap 5.3, Bootstrap Icons y Google Fonts.
Las imágenes, el video y el mapa usan servicios externos; se necesita conexión a internet para verlos.
